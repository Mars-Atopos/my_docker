'''
Created by auto_sdk on 2020.09.27
'''
from dingtalk.api.base import RestApi
class OapiCrmObjectdataContactQueryRequest(RestApi):
	def __init__(self,url=None):
		RestApi.__init__(self,url)
		self.current_operator_userid = None
		self.cursor = None
		self.page_size = None
		self.provider_corpid = None
		self.query_dsl = None

	def getHttpMethod(self):
		return 'POST'

	def getapiname(self):
		return 'dingtalk.oapi.crm.objectdata.contact.query'
