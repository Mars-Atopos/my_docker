'''
Created by auto_sdk on 2019.10.08
'''
from dingtalk.api.base import RestApi
class OapiCspaceAuthCancelRequest(RestApi):
	def __init__(self,url=None):
		RestApi.__init__(self,url)
		self.agent_id = None
		self.isv_code = None

	def getHttpMethod(self):
		return 'POST'

	def getapiname(self):
		return 'dingtalk.oapi.cspace.auth.cancel'
