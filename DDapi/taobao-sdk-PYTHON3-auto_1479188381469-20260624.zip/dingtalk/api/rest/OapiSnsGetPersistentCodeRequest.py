'''
Created by auto_sdk on 2018.07.25
'''
from dingtalk.api.base import RestApi
class OapiSnsGetPersistentCodeRequest(RestApi):
	def __init__(self,url=None):
		RestApi.__init__(self,url)
		self.tmp_auth_code = None

	def getHttpMethod(self):
		return 'POST'

	def getapiname(self):
		return 'dingtalk.oapi.sns.get_persistent_code'
